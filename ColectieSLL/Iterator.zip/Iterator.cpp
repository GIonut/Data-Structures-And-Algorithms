#pragma once
#include "Iterator.h"
#include "Colectie.h"


IteratorColectie::IteratorColectie(const Colectie& c) : col(c) {
	/* de adaugat */
	curent = col.prim;
}

TElem IteratorColectie::element() const {
	/* de adaugat */
	return curent->element();
}

bool IteratorColectie::valid() const {
	/* de adaugat */
	if (curent != nullptr)
		return true;
	return false;
}

void IteratorColectie::urmator() {
	/* de adaugat */
	curent++;
}

void IteratorColectie::prim() {
	/* de adaugat */
	curent = col.prim;
}