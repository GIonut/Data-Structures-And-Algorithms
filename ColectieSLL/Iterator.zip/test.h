#pragma once

#include "Colectie.h"

void test()
{
	Colectie c;
}